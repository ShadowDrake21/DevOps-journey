#!/bin/bash

function first() {
	x="Hello Geek"
	echo "Inside first function x=$x"
}

first
echo "Outside first function x=$x"
